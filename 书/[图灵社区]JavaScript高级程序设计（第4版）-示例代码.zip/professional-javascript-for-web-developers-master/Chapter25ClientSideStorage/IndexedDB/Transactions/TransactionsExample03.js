let transaction = db.transaction(["users", "anotherStore"]);
