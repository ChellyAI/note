// start at item after "007", go to the end
const lowerRange  = IDBKeyRange.lowerBound("007", true);
