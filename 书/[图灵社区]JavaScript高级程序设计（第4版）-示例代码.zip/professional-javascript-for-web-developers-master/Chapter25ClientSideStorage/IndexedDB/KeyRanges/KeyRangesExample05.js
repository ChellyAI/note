// start at beginning, go to the item just before "ace"
const upperRange  = IDBKeyRange.upperBound("ace", true);
