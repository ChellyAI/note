// start at beginning, go to "ace"
const upperRange  = IDBKeyRange.upperBound("ace");
