// start at item "007", go to the end
const lowerRange  = IDBKeyRange.lowerBound("007");
