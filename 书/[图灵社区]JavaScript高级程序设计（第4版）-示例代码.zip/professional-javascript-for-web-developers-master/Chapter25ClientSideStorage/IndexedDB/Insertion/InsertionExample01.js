// where users is an array of new users
for (let user in users) {
  store.add(user);
}
