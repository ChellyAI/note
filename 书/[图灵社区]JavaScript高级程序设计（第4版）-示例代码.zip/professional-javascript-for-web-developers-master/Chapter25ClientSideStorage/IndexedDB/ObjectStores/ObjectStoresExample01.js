let user = {
  username: "007",
  firstName: "James",
  lastName: "Bond",
  password: "foo"
};
