// store data using method
localStorage.setItem("name", "Nicholas");
                   
// store data using property
localStorage.book = "Professional JavaScript";
                   
// get data using method
let name = localStorage.getItem("name");
                   
// get data using property
let book = localStorage.book;
