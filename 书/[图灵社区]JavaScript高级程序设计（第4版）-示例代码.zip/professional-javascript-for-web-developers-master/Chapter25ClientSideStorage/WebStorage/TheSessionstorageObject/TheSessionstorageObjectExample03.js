// get data using method
let name = sessionStorage.getItem("name");
                   
// get data using property
let book = sessionStorage.book;
