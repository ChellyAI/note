// use delete to remove a value
delete sessionStorage.name;
                   
// use method to remove a value
sessionStorage.removeItem("book");
