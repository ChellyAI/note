// store data using method
sessionStorage.setItem("name", "Nicholas");
                   
// store data using property
sessionStorage.book = "Professional JavaScript";
