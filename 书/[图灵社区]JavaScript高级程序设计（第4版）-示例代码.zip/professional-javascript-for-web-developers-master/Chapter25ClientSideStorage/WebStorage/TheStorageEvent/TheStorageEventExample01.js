window.addEventListener("storage", 
    (event) => alert(`Storage changed for ${event.domain}`));
