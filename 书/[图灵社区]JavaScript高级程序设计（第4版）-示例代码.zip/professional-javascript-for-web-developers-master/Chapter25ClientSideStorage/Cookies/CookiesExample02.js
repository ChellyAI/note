GET /index.jsl HTTP/1.1
Cookie: name=value
Other-header: other-header-value
