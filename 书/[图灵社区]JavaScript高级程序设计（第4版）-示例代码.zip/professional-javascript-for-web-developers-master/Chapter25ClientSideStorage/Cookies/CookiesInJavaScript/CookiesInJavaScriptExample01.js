name1=value1;name2=value2;name3=value3
