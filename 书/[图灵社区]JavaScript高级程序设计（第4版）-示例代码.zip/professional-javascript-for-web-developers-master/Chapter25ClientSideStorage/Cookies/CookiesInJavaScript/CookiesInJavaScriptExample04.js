document.cookie = encodeURIComponent("name") + "=" +  
                  encodeURIComponent("Nicholas");
