name=value; expires=expiration_time; path=domain_path; domain=domain_name; secure
