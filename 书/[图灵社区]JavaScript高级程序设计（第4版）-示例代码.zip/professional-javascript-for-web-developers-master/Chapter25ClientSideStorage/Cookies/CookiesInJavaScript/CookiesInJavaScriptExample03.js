document.cookie = "name=Nicholas";
