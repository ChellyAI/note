document.cookie = encodeURIComponent("name") + "=" +  
                  encodeURIComponent("Nicholas") + "; domain=.wrox.com; path=/";
