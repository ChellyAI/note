// just remove the "name" subcookie
SubCookieUtil.unset("data", "name");
                   
// remove the entire cookie
SubCookieUtil.unsetAll("data");
