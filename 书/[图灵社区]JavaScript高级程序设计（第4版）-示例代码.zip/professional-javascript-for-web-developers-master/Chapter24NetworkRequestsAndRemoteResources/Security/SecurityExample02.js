xhr.open("get", "example.php", true, "username", "password");   // AVOID!!!!!
