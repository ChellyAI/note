/getuserinfo.php?id=23
