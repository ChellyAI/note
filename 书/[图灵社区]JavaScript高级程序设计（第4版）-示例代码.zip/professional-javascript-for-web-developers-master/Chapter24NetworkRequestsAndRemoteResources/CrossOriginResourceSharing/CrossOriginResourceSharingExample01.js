Origin: http://www.somewhere-else.com
