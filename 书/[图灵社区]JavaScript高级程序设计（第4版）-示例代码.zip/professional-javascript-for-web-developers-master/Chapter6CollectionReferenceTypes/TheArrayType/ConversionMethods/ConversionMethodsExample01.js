let colors = ["red", "blue", "green"];  // creates an array with three strings
alert(colors.toString());  // red,blue,green
alert(colors.valueOf());   // red,blue,green
alert(colors);             // red,blue,green
