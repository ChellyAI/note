let colors = ["red", "green", "blue"];
alert(colors.join(","));    // red,green,blue
alert(colors.join("||"));   // red||green||blue
