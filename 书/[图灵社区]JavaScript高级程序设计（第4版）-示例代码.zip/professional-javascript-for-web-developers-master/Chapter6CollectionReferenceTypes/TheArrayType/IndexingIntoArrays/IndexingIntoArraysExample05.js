let colors = ["red", "blue", "green"];  // creates an array with three strings
colors[colors.length] = "black";        // add a color (position 3)
colors[colors.length] = "brown";        // add another color (position 4)
