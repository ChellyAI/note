let colors = ["red", "blue", "green"];  // creates an array with three strings
let names = [];                         // creates an empty array
           
alert(colors.length);  // 3
alert(names.length);   // 0
