let colors = new Array();
