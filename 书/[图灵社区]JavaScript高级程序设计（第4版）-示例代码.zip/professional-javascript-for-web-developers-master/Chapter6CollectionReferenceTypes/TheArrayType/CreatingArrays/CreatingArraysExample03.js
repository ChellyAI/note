let colors = new Array("red", "blue", "green");
