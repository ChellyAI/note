let colors = Array(3);      // create an array with three items
let names = Array("Greg");  // create an array with one item, the string "Greg"
