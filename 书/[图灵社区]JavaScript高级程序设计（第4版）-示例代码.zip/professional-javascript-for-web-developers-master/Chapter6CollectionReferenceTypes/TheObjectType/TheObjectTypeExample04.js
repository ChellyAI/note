let person = {};  // same as new Object()
person.name = "Nicholas";
person.age = 29;
