let person = {
  "name": "Nicholas",
  "age": 29,
  5: true
};
