let propertyName = "name";
alert(person[propertyName]);  // "Nicholas"
