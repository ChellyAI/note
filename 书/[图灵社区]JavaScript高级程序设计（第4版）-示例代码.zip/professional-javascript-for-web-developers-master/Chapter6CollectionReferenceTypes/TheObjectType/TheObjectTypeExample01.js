let person = new Object();
person.name = "Nicholas";
person.age = 29;
