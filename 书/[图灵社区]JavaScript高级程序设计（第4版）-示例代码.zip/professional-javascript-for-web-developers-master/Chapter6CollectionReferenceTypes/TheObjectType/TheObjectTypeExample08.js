person["first name"] = "Nicholas";
