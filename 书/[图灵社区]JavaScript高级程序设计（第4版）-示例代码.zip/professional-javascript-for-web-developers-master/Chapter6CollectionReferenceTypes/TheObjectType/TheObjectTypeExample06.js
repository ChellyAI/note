alert(person["name"]);  // "Nicholas"
alert(person.name);     // "Nicholas"
