let arr1 = [1, 2, 3];
let arr2 = [0, ...arr1, 4, 5];

console.log(arr2);  // [0, 1, 2, 3, 4, 5] 
