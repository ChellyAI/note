let isBold = frames["richedit"].document.queryCommandState("bold");
