let result = frames["richedit"].document.queryCommandEnabled("bold");
