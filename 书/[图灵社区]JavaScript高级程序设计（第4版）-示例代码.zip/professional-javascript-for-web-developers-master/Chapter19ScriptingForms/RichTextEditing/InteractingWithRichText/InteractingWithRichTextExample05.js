let fontSize = frames["richedit"].document.queryCommandValue("fontsize");
