// toggle bold text
document.execCommand("bold", false, null);
            
// toggle italic text
document.execCommand("italic", false, null);
            
// create link to www.wrox.com
document.execCommand("createlink", false, "http://www.wrox.com");
            
// format as first-level heading
document.execCommand("formatblock", false, "<h1>");
