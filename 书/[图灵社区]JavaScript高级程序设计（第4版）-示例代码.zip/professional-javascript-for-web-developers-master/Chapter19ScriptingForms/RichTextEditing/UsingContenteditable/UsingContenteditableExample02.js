let div = document.getElementById("richedit");
richedit.contentEditable = "true";
