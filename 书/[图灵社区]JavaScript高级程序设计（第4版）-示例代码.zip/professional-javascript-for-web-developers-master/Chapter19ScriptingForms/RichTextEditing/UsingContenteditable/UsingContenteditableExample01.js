<div class="editable" id="richedit" contenteditable></div>
