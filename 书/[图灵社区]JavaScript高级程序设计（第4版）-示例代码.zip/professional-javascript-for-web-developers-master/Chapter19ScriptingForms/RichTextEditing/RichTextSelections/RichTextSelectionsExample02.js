let range = frames["richedit"].document.selection.createRange();
let selectedText = range.text;
