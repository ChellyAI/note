<!-- generic submit button -->
<input type="submit" value="Submit Form">
            
<!-- custom submit button -->
<button type="submit">Submit Form</button>
            
<!-- image button -->
<input type="image" src="graphic.gif">
