let form = document.getElementById("myForm");

form.addEventListener("submit", (event) => {
  // prevent form submission
  event.preventDefault();
});
