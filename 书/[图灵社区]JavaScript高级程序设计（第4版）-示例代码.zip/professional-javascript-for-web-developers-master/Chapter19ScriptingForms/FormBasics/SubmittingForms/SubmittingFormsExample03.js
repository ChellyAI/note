let form = document.getElementById("myForm");
            
// submit the form
form.submit();
