let form = document.getElementById("form1");
            
// get the first field in the form
let field1 = form.elements[0];
            
// get the field named "textbox1"
let field2 = form.elements["textbox1"];
            
// get the number of fields
let fieldCount = form.elements.length;
