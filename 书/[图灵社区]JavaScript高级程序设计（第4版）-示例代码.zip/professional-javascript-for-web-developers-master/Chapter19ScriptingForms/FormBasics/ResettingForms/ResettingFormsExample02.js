let form = document.getElementById("myForm");

form.addEventListener("reset", (event) => {
  event.preventDefault();
});
