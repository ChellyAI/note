let form = document.getElementById("myForm");
            
// reset the form
form.reset();
