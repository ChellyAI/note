<!-- generic reset button -->
<input type="reset" value="Reset Form">
            
<!-- custom reset button -->
<button type="reset">Reset Form</button>
