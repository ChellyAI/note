textbox.addEventListener("focus", (event) => {
  event.target.select();
});
