let textbox = document.forms[0].elements["textbox1"];
textbox.select();
