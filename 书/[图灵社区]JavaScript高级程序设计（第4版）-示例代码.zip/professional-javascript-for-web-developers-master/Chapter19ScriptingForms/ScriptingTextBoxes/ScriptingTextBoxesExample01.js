<input type="text" size="25" maxlength="50" value="initial value">
