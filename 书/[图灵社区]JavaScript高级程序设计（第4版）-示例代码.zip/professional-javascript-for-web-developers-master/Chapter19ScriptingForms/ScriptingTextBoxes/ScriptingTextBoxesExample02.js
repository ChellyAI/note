<textarea rows="25" cols="5">initial value</textarea>
