selectbox.options[0] = null;     // remove first option
