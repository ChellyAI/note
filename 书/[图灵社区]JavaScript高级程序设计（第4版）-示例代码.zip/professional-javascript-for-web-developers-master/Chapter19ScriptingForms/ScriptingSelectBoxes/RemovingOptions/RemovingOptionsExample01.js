selectbox.removeChild(selectbox.options[0]);   // remove first option 
