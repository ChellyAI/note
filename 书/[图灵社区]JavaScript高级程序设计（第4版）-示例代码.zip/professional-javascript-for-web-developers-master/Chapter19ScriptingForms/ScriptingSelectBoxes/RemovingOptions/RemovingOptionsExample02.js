selectbox.remove(0);   // remove first option 
