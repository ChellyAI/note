let newOption = new Option("Option text", "Option value");
selectbox.add(newOption, undefined);    // best solution
