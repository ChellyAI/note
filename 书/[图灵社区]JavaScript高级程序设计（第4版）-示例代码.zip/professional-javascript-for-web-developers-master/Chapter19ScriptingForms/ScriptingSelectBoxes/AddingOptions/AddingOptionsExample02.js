let newOption = new Option("Option text", "Option value");
selectbox.appendChild(newOption);    // problems in IE <= 8
