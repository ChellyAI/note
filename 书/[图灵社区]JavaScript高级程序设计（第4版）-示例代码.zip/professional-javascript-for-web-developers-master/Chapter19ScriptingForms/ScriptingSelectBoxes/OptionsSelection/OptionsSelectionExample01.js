let selectedOption = selectbox.options[selectbox.selectedIndex];
