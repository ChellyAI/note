selectbox.options[0].selected = true;
