let selectbox = document.forms[0].elements["location"];
            
// preferred
let text = selectbox.options[0].text;     // option text
let value = selectbox.options[0].value;   // option value
