let selectbox1 = document.getElementById("selLocations1");
let selectbox2 = document.getElementById("selLocations2");
            
selectbox2.appendChild(selectbox1.options[0]);
