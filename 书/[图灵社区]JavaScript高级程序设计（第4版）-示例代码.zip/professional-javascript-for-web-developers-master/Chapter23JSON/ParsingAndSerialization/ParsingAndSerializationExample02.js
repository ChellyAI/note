doc.getElementsByTagName("book")[2].getAttribute("title");
