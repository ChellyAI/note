const s = Symbol('foo');

console.log(s.toString());
// Symbol(foo)
