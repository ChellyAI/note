console.log(person1.constructor == Person);  // true
console.log(person2.constructor == Person);  // true
