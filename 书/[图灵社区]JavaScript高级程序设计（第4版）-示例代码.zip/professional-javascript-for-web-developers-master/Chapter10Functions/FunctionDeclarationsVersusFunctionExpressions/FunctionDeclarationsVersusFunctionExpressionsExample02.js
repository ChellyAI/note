// Error
console.log(sum(10, 10));
let sum = function(num1, num2) {
  return num1 + num2;
};
