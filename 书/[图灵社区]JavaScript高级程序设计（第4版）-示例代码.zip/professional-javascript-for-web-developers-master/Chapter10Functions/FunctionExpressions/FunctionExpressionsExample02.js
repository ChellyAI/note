sayHi();
function sayHi() {
  console.log("Hi!");
}
