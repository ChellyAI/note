function functionName(arg0, arg1, arg2) {
  // function body
}
