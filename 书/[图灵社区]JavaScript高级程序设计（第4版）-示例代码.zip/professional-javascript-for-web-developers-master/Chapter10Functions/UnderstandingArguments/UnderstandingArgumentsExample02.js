function sayHi() {
  console.log("Hello " + arguments[0] + ", " + arguments[1]);
}
