console.log(getSum.apply(null, values));  // 10 
