function add(num1, num2) {
  let sum = num1 + num2;
  return sum;
}  
