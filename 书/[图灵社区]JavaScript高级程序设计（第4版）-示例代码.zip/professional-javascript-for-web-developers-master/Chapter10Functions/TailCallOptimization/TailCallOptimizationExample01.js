function outerFunction() {
  return innerFunction();  // tail call
}
