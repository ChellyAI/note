"use strict";
let result = eval("let x = 10, y = 11; x + y");
alert(result);    // 21
