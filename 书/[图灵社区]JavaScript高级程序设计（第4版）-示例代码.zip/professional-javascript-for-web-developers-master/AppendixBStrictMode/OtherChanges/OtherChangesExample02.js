// Use of octal literal
// Non-strict mode: value is 8.
// Strict mode: throws a syntax error.
let value = 010;
