// Deleting a variable
// Non-strict mode: Fails silently
// Strict mode: Throws a ReferenceError
let color = "red";
delete color;
