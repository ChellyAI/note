// Variable is not declared
// Non-strict mode: creates a global
// Strict mode: Throws a ReferenceError
message = "Hello world!";
