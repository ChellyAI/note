// Duplicate named arguments
// Non-strict mode: No error, only second argument works
// Strict mode: Throws a SyntaxError
function sum (num, num){
  // do something
}
