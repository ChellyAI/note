// Redefining eval and arguments as variables
// Non-strict mode: Okay, no error.
// Strict-mode: Throws syntax error
let eval = 10;
let arguments = "Hello world!";
