// go back one page
history.back();
           
// go forward one page
history.forward();
