// go back one page
history.go(-1);
           
// go forward one page
history.go(1);
           
// go forward two pages
history.go(2);
