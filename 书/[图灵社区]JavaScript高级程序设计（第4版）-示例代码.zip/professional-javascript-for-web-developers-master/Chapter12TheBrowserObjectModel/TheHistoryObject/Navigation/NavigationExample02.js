// go to nearest wrox.com page
history.go("wrox.com");
           
// go to nearest somewhere-else.com page
history.go("somewhere-else.com");
