if (history.length == 0){
  //this is the first page in the user's window
}
