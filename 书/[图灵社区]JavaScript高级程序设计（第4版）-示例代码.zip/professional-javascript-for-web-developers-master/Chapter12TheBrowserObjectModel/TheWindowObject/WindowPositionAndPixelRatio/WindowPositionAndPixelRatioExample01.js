// move the window to the upper-left coordinate
window.moveTo(0,0);
           
// move the window down by 100 pixels
window.moveBy(0, 100);
           
// move the window to position (200, 300)
window.moveTo(200, 300);
           
// move the window left by 50 pixels
window.moveBy(-50, 0);
