let result = prompt("What is your name? ", "");
if (result !== null) {
  alert("Welcome, " + result);
}
