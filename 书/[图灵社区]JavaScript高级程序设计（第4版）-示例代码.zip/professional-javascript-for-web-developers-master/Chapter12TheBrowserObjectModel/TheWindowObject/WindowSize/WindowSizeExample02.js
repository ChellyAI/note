// resize to 100 x 100
window.resizeTo(100, 100);
           
// resize to 200 x 150
window.resizeBy(100, 50);
           
// resize to 300 x 300
window.resizeTo(300, 300);
