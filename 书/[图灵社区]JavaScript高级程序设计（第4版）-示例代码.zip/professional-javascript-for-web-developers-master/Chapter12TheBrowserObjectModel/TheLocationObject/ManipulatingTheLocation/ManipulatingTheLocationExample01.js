location.assign("http://www.wrox.com");
