// assume starting at http://www.wrox.com/WileyCDA/
           
// changes URL to "http://www.wrox.com/WileyCDA/#section1"
location.hash = "#section1";
           
// changes URL to "http://www.wrox.com/WileyCDA/?q=javascript"
location.search = "?q=javascript";
           
// changes URL to "http://www.somewhere.com/WileyCDA/"
location.hostname = "www.somewhere.com";
           
// changes URL to "http://www.somewhere.com/mydir/"
location.pathname = "mydir";
           
// changes URL to "http://www.somewhere.com:8080/WileyCDA/
Location.port = 8080;
