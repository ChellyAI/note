let s1 = "some text";
let s2 = s1.substring(2);
