let obj = new Object("some text");
console.log(obj instanceof String);   // true
