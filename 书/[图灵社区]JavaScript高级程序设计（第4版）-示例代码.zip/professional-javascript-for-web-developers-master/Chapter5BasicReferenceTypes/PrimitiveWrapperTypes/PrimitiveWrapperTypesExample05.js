let value = "25";
let number = Number(value);   // casting function
console.log(typeof number);     // "number"
let obj = new Number(value);  // constructor
console.log(typeof obj);        // "object"
