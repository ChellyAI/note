let num = 10;
console.log(num.toFixed(2));  // "10.00"
