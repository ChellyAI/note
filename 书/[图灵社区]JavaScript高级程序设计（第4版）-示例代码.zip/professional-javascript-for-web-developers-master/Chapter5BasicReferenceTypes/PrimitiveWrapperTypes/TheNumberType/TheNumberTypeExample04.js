let num = 10.005;
console.log(num.toFixed(2));  // "10.01"
