let s1 = "some text";
s1.color = "red";
console.log(s1.color);   // undefined
