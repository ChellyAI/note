let pattern = new RegExp("\\[bc\\]at", "gi");
console.log(pattern.toString());      // /\[bc\]at/gi
console.log(pattern.toLocaleString());  // /\[bc\]at/gi
