let expression = /pattern/flags;
