let date1 = new Date(2017, 0, 1);    // "January 1, 2017"
let date2 = new Date(2017, 1, 1);    // "February 1, 2017"
         
console.log(date1 < date2);  // true
console.log(date1 > date2);  // false
