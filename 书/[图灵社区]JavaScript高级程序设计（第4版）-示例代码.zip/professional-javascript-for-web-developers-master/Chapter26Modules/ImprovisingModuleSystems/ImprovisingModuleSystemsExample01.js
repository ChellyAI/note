(function() {
  // private Foo module code
  console.log('bar');
})();

// 'bar'
