var Foo = (function() {
  console.log('bar');
})();

'bar'
