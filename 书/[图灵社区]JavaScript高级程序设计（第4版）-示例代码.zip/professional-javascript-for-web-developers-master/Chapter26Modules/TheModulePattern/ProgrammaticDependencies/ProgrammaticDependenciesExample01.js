if (loadCondition) {
  require('./moduleA');
}
