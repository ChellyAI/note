 export { default } from './foo.js'; 
