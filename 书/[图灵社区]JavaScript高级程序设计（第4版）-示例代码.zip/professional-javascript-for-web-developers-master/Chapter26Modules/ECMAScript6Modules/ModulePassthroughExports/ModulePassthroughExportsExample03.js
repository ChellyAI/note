export { foo, bar as myBar } from './foo.js'; 
