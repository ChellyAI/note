import './foo.js';
