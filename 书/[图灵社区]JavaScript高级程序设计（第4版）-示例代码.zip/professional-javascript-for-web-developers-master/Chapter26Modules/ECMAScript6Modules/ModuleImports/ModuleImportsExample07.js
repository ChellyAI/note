import { foo, bar, baz as myBaz } from './foo.js';

console.log(foo);    // foo 
console.log(bar);    // bar
console.log(myBaz);  // baz
