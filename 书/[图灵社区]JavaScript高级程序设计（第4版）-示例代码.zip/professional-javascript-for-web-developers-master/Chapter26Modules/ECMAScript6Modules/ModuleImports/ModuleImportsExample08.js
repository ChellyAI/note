// Equivalent
import { default as foo } from './foo.js';
import foo from './foo.js';
