// Resolves to /components/bar.js
import ... from './bar.js'; 

// Resolves to /bar.js
import ... from '../bar.js';

// Resolves to /bar.js
import ... from '/bar.js';
