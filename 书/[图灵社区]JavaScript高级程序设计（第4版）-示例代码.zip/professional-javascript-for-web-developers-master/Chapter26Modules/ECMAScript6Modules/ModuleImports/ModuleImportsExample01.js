// Allowed
import ...

// Disallowed
if (condition) {
  import ...
}
