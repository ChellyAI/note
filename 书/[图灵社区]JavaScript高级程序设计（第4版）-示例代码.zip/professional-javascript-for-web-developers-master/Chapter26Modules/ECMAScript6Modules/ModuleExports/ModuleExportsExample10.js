const foo = 'foo';
const bar = 'bar';

export { bar };
export default foo; 
