const foo = 'foo';

// Behaves identically to "export default foo;"
export { foo as default };
