const foo = 'foo';
export { foo as myFoo };
