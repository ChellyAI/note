const foo = 'foo';
const bar = 'bar';
const baz = 'baz';

export { foo, bar as myBar, baz }; 
