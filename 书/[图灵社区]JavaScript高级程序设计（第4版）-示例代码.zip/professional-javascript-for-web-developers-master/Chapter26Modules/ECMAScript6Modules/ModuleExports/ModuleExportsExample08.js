const foo = 'foo';
export default foo;
