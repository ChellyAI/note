const foo = 'foo';
const bar = 'bar';

export { foo as default, bar }; 
