// Allowed
export ...

// Disallowed
if (condition) {
  export ...
}
