const foo = 'foo';
export { foo };
