var moduleA = require('./moduleB');

console.log(moduleB);  // 'foo' 
