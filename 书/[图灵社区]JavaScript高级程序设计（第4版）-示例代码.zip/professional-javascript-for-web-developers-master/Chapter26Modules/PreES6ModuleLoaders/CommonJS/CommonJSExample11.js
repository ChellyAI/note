class A {}

module.exports = new A(); 
