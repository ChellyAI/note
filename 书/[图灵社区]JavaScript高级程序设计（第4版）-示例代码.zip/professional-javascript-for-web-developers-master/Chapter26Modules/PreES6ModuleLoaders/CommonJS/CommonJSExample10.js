class A {}

module.exports = A; 
var A = require('./moduleA');

var a = new A();
