var moduleB = require('./moduleB');

module.exports = {
  stuff: moduleB.doStuff();
}; 
