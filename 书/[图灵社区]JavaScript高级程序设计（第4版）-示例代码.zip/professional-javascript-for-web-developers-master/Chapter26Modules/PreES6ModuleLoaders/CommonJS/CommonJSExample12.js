
if (condition) {
  var A = require('./moduleA');
} 
