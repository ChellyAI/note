var moduleA = require('./moduleA');

console.log(moduleA.stuff); 
