console.log('moduleA');
require('./moduleA');
require('./moduleB');  // "moduleA"
require('./moduleA');
