console.log('moduleA');
require('./moduleA');  // "moduleA"
