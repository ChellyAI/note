console.log('moduleA');
if (loadCondition) {
  require('./moduleA');
}
