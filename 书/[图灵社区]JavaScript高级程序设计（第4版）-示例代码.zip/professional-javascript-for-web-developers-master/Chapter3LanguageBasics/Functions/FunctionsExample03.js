sayHi("Nicholas", "how are you today?");
