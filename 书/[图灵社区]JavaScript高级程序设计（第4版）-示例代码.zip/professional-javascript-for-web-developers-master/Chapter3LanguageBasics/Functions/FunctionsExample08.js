function sayHi(name, message) {
  return;
  console.log("Hello " + name + ", " + message);  // never called
}
