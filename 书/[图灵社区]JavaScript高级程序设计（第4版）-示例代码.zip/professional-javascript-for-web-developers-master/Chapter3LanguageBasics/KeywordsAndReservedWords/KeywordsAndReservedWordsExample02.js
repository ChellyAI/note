Always reserved:

enum        


Reserved in strict mode:

implements  package     public
interface   protected   static
let         private


Reserved in module code:

await

